gcc -Wall -g -o main *.c
