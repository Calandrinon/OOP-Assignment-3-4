./compile.sh
./main
rm main
